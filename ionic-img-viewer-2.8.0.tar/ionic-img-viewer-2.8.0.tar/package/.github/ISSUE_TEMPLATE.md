### Please provide you version information :
Dependency      |Version
----------------|-------
ionic2          | 
angular         |
ionic-img-viewer|

### Have you checked...
- [ ] That npm install returns no warning ?
- [ ] Doing a purge of your node_modules folder ?

