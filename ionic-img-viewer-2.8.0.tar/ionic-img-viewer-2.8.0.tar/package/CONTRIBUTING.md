# Contributing

We love pull requests from everyone.

Fork the repo:

```
git clone git@github.com:Riron/ionic-img-viewer.git
```

Write a [good commit message][commit].
Push to your fork.
[Submit a pull request][pr].

[commit]: http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html
[pr]: https://github.com/Riron/ionic-img-viewer/compare/

Wait for us :)